1. When this program is run, it is important to run "gradebook"
   to see the results you want.

2. Files are distributed in appropriate folders. For example
   transcripts.txt are found in transcripts folder.

3. This submission is as for Programming and Problem solving for
   Data Analytics course at Carnegie Mellon University.